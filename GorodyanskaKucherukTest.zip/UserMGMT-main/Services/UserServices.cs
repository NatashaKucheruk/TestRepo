public class UserService : IUserService
{
    private readonly List<User> _users = new List<User>(); 
    private int _nextId = 1;  

    public async Task<IEnumerable<User>> GetAllUsersAsync()
    {
        return await Task.FromResult(_users);
    }

    public async Task<User> GetUserByIdAsync(int id)
    {
        return await Task.FromResult(_users.FirstOrDefault(u => u.Id == id));
    }

    public async Task<User> CreateUserAsync(User user)
    {
        user.Id = _nextId++;
        _users.Add(user);
        return await Task.FromResult(user);
    }

    public async Task<bool> UpdateUserAsync(User user)
    {
        var existingUser = _users.FirstOrDefault(u => u.Id == user.Id);

        if (existingUser == null)
        {
            return await Task.FromResult(false);
        }

        existingUser.Name = user.Name;
        existingUser.Email = user.Email;

        return await Task.FromResult(true);
    }

    public async Task<bool> DeleteUserAsync(int id)
    {
        var existingUser = _users.FirstOrDefault(u => u.Id == id);

        if (existingUser == null)
        {
            return await Task.FromResult(false);
        }

        _users.Remove(existingUser);

        return await Task.FromResult(true);
    }
}