using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;


public class TokenValidationMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<TokenValidationMiddleware> _logger;

    // You might want to inject a token validation service here
    // private readonly ITokenValidationService _tokenService;

    public TokenValidationMiddleware(
        RequestDelegate next,
        ILogger<TokenValidationMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Skip token validation for certain paths (like login endpoints)
        if (ShouldSkipValidation(context.Request.Path))
        {
            await _next(context);
            return;
        }

        // Check for the Authorization header
        if (!context.Request.Headers.TryGetValue("Authorization", out var authHeader))
        {
            _logger.LogWarning("Request missing Authorization header");
            await SendUnauthorizedResponseAsync(context, "Authorization header is missing");
            return;
        }

        string token = authHeader.ToString();

        // Basic validation - check if token starts with "Bearer "
        if (!token.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogWarning("Invalid token format");
            await SendUnauthorizedResponseAsync(context, "Invalid token format");
            return;
        }

        // Extract the token value
        token = token.Substring("Bearer ".Length).Trim();

        if (string.IsNullOrEmpty(token))
        {
            _logger.LogWarning("Empty token provided");
            await SendUnauthorizedResponseAsync(context, "Token is empty");
            return;
        }

        // Implement your token validation logic here
        // This is a placeholder implementation, replace with actual token validation
        if (!IsValidToken(token))
        {
            _logger.LogWarning("Invalid token provided: {TokenPrefix}...", token.Substring(0, Math.Min(10, token.Length)));
            await SendUnauthorizedResponseAsync(context, "Invalid or expired token");
            return;
        }

        // Token is valid, continue with the request
        await _next(context);
    }

    private bool ShouldSkipValidation(PathString path)
    {
        // Skip validation for login, register endpoints and Swagger docs
        return path.StartsWithSegments("/api/auth/login") ||
               path.StartsWithSegments("/api/auth/register") ||
               path.StartsWithSegments("/swagger");
    }

    private bool IsValidToken(string token)
    {
        // Replace this with your actual token validation logic
        // For example, JWT token validation or checking against a database

        // This is just a placeholder implementation
        return !string.IsNullOrEmpty(token) && token.Length > 10;
    }

    private async Task SendUnauthorizedResponseAsync(HttpContext context, string message)
    {
        context.Response.ContentType = "application/json";
        context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;

        var response = new
        {
            StatusCode = context.Response.StatusCode,
            Message = message
        };

        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        var json = JsonSerializer.Serialize(response, options);
        await context.Response.WriteAsync(json);
    }
}

// Extension method for registering the middleware
public static class TokenValidationMiddlewareExtensions
{
    public static IApplicationBuilder UseTokenValidation(this IApplicationBuilder builder)
    {
        return builder.UseMiddleware<TokenValidationMiddleware>();
    }
}
